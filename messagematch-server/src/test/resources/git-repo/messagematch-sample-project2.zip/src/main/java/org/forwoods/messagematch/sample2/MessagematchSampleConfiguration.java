package org.forwoods.messagematch.sample2;

import io.dropwizard.Configuration;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.validator.constraints.*;
import javax.validation.constraints.*;

public class MessagematchSampleConfiguration extends Configuration {
}
